package com.Group3.JavaSpringExam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSpringExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaSpringExamApplication.class, args);
	}

}
